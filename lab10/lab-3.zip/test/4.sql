.headers on

SELECT s_name
FROM supplier
WHERE s_acctbal > 8000;
