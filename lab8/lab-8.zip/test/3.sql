.eqp on
.headers on

select c_address, c_phone, c_acctbal
from customer
where c_name='Customer#000000227';
