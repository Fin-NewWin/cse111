#!/bin/bash

rm -f output/*

#javac Lab_7.java
#java -classpath ".:sqlite-jdbc-3.32.3.2.jar" Lab_7

python3 Lab_7.py
