.headers on

SELECT
    region
FROM
    (SELECT
        region,
        MAX(total)
    FROM
        (SELECT
            r_name AS region,
            SUM(l_extendedprice) AS total
        FROM
            customer,
            orders,
            lineitem,
            supplier,
            nation,
            region
        WHERE
            c_custkey = o_custkey
            AND 
            l_orderkey = o_orderkey
            AND 
            l_suppkey = s_suppkey
            AND 
            c_nationkey = n_nationkey
            AND 
            s_nationkey = n_nationkey
            AND 
            n_regionkey = r_regionkey
        GROUP BY
            r_name));
